package com.mycompany.punto_4_eventos;

import java.util.ArrayList;
import java.text.DateFormat;
import java.util.Calendar;

public class ListaEventos {
    public ArrayList<Evento> eventos = new ArrayList<Evento>();
    
    //Guardar evento a la lista
    public String guardarEvento(Evento evento){
        if(!this.enLista(evento)){
            this.eventos.add(evento);
            return "Guardado";
        }
        else{
            return "Ya esta guardado";
        }
        
    }
    
    //Ver cantidad de eventos en la lista
    public int cantidadEventos(){
        return this.eventos.size();
    }
    
    //Eliminar todos los eventos de la lista
    public void eliminarTodo(){
        this.eventos.clear();
    }
    
    //Eliminar un evento de la lista
    public String eliminarEvento(Evento evento){
        if(this.enLista(evento)){
            this.eventos.remove(evento);
            return "Eleminado";
        }
        else{
            return "No esta en la lista";
        }
    }
    
    //Revisar si un elemento esta en la lista
    public boolean enLista(Evento evento){
        return this.eventos.contains(evento);
    }
    
    //Imprimir la informacion de todos los elementos de la lista
    public void verEventos(){
        DateFormat df = DateFormat.getDateInstance();
        System.out.println("---------------------------");
        System.out.println("Eventos guardados: " + this.cantidadEventos());
        System.out.println("---------------------------");
        for(int i = 0;i < this.eventos.size(); i++){
            Evento evento = this.eventos.get(i);
            System.out.println("---------------------------");
            System.out.println("Id evento: " + evento.getId());
            System.out.println("Nombre del evento: " + evento.getNombre());
            System.out.println("Direccion del evento: " + evento.getDireccion());
            System.out.println("Hora del evento: " + evento.getHora().toString());
            System.out.println("Fecha del evento: " + evento.getFecha().get(Calendar.DATE) + "/" + evento.getFecha().get(Calendar.MONTH) + "/" + evento.getFecha().get(Calendar.YEAR));
            System.out.println("---------------------------");
        }
    }
}
