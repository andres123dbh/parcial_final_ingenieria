package com.mycompany.punto_4_eventos;

import java.sql.Time;
import java.util.Calendar;
import org.junit.Test;
import static org.junit.Assert.*;

public class ListaEventosTest {
    Time horaEvento = new Time(11,0,0);
    Calendar fecha = Calendar.getInstance();
    

    //Prueba del metodo guardarEvento
    @Test
    public void testGuardarEvento() {
        ListaEventos listaEventos = new ListaEventos();
        fecha.set(2021, 11, 14);
        Evento evento = new Evento(1,"buendia","Primitivo Bogota",horaEvento,fecha);
        
        assertEquals("Guardado",listaEventos.guardarEvento(evento));
        
        assertEquals("Ya esta guardado",listaEventos.guardarEvento(evento));
    }

    //Prueba del metodo  cantidadEventos
    @Test
    public void testCantidadEventos() {
        ListaEventos listaEventos = new ListaEventos();
        Evento evento = new Evento(1,"buendia","Primitivo Bogota",horaEvento,fecha);
        Evento evento2 = new Evento(2,"buendia","Primitivo Bogota",horaEvento,fecha);
        Evento evento3 = new Evento(3,"buendia","Primitivo Bogota",horaEvento,fecha);
        listaEventos.guardarEvento(evento);
        listaEventos.guardarEvento(evento2);
        listaEventos.guardarEvento(evento3);
        assertEquals(3,listaEventos.cantidadEventos(),0);
    }

    //Prueba del metodo eliminarTodo
    @Test
    public void testEliminarTodo() {
        ListaEventos listaEventos = new ListaEventos();
        Evento evento = new Evento(1,"buendia","Primitivo Bogota",horaEvento,fecha);
        Evento evento2 = new Evento(2,"buendia","Primitivo Bogota",horaEvento,fecha);
        Evento evento3 = new Evento(3,"buendia","Primitivo Bogota",horaEvento,fecha);
        listaEventos.guardarEvento(evento);
        listaEventos.guardarEvento(evento2);
        listaEventos.guardarEvento(evento3);
        listaEventos.eliminarTodo();
        assertEquals(0,listaEventos.cantidadEventos(),0);
    }

    //Prueba del metodo eliminarEvento
    @Test
    public void testEliminarEvento() {
        ListaEventos listaEventos = new ListaEventos();
        Evento evento = new Evento(1,"buendia","Primitivo Bogota",horaEvento,fecha);
        assertEquals("No esta en la lista",listaEventos.eliminarEvento(evento));
        listaEventos.guardarEvento(evento);
        assertEquals("Eleminado",listaEventos.eliminarEvento(evento));
    }

    //Prueba metoso enLista
    @Test
    public void testEnLista() {
        ListaEventos listaEventos = new ListaEventos();
        Evento evento = new Evento(1,"buendia","Primitivo Bogota",horaEvento,fecha);
        assertEquals(false,listaEventos.enLista(evento));
        listaEventos.guardarEvento(evento);
        assertEquals(true,listaEventos.enLista(evento));
    }

    
}
